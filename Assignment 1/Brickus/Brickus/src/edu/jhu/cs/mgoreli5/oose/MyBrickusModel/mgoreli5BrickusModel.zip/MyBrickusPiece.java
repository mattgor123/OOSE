package edu.jhu.cs.mgoreli5.oose.MyBrickusModel;
import java.util.*;
import edu.jhu.cs.oose.fall2013.brickus.iface.BrickusEvent;
import edu.jhu.cs.oose.fall2013.brickus.iface.BrickusListener;
import edu.jhu.cs.oose.fall2013.brickus.iface.BrickusPiece;

public class MyBrickusPiece implements BrickusPiece {

	/**
	 * Represent the width and the height of the piece
	 */
	private int width;
	private int height;
	
	/**
	 * 2-way array used to represent the actual piece
	 */
	private boolean[][] gridPiece;
	
	List<BrickusListener> listeners;
	private MyBrickusModel model;
	
	/**
	 * The constructor, which will be called from the model to make all the pieces
	 * @param width	The width of the piece to create
	 * @param height	The height of the piece to create
	 * @param grid	The grid from which to create the piece
	 * @param listeners	The listeners for the piece
	 * @param model	The model to which the piece is associated
	 */
	public MyBrickusPiece (int width, int height, boolean[][] grid, List<BrickusListener> listeners, MyBrickusModel model)
	{
		this.width = width;
		this.height = height;	
		this.model = model;
		this.listeners = listeners;
		//Using different sized grid based on the size of the piece
		this.gridPiece = new boolean[width][height];
		//Iterate through the new grid, populating the appropriate squares based on the passed grid
		//Could check for invalidly sized grids being passed to avoid array out of bounds exceptions, but since I know whenever it's being called in the model class I didn't think it was necessary
		for(int i=0;i<width;i++)
			for(int j=0;j<height;j++)
				this.gridPiece[i][j]=grid[i][j];	
	}
	
	/**
	 * Implementation of the interface's method used to return the height of the piece
	 */
	public int getHeight()
	{
		return height;
	}
	
	/**
	 * Implementation of the interface's method used to return the height of the piece
	 */
	public int getWidth()
	{
		return width;
	}
	
	/**
	 * Implementation of the interface's method used to flip the piece horizontally about its center (preserving the size of the grid)
	 */
	public void flipHorizontally()
	{
		boolean[][] flipHoriz = new boolean[width][height];
		for (int i = 0; i < this.width; i++)
			for (int j = 0; j < this.height; j++)
				//We just need to flip piece's horizontal orientation
				flipHoriz[i][j]=this.gridPiece[(this.width-1)-i][j];
		this.gridPiece = flipHoriz;
		for (BrickusListener listener : this.listeners)
			listener.modelChanged(new BrickusEvent(this.model,false,false));
	}
	
	/**
	 * Implementation of the interface's method used to flip the piece vertically about its center (preserving the size of the grid)
	 */
	public void flipVertically()
	{
		boolean[][] flipVert = new boolean[width][height];
		for (int i = 0; i < this.width; i++)
			for (int j = 0; j < this.height; j++)
				//We just need to flip piece's vertical orientation
				flipVert[i][j]=this.gridPiece[i][(this.height-1)-j];
		this.gridPiece = flipVert;
		for (BrickusListener listener : this.listeners)
			listener.modelChanged(new BrickusEvent(this.model,false,false));
	}
	
	/**
	 * Implementation of the interface's method used to rotate the piece 90 degrees clockwise
	 */
	public void rotateClockwise()
	{
		//We will need a differently sized grid to represent this piece if the width =/= height
		boolean[][] rotClock = new boolean[height][width];
		for (int i = 0; i < this.height; i++)
			for (int j = 0; j < this.width; j++)
				//Swap width and height, and preserve the piece orientation
				rotClock[i][j]=this.gridPiece[j][(this.height-1)-i];
		this.gridPiece = rotClock;
		//Need to make sure the piece knows its new width and height
		int rotHeight = this.width;
		this.width = this.height;
		this.height = rotHeight;
		for (BrickusListener listener : this.listeners)
			listener.modelChanged(new BrickusEvent(this.model,false,false));
	}
	
	/**
	 * Implementation of the interface's method used to rotate the pieces 90 degrees counterclockwise
	 */
	public void rotateCounterClockwise()
	{
		//Again, differently sized grid necessary to represent the rotation
		boolean[][] rotCClock = new boolean[height][width];
		for (int i = 0; i < this.height; i++)
			for (int j = 0; j < this.width; j++)
				//Swap width and height, again preserving the piece orientation but in the other direction
				rotCClock[i][j]=this.gridPiece[(this.width-1)-j][i];
		this.gridPiece=rotCClock;
		int rotHeight = this.width;
		this.width = this.height;
		this.height = rotHeight;
		for (BrickusListener listener : this.listeners)
			listener.modelChanged(new BrickusEvent(this.model,false,false));
	}
	
	/**
	 * Implementation of the interface's method used to determine if the piece's grid has a certain square checked wrt the origin
	 */
	public boolean isOccupied(int x, int y)
	{
		return this.gridPiece[x][y];
	}
	
}
